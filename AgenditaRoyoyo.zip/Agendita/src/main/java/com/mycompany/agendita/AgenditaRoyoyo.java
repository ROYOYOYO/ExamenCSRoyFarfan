#include <iostream>					
#include <string.h>					
#include <windows.h>				
#include <stdio.h>

#define CANTIDAD 500 				

using namespace std;


int ContactosRegistrados = 0;
int ContactosEliminados  = 0;
string Regla = "=============================================================";


struct Cumple {
	string Nacimiento;
};


struct Agenda {
	string Nombre;
	string Telefono;
	string Celular;
	string Email;
	Cumple Fecha;					
	Agenda();  						
};



int MenuPrimario();					
int MenuSecundario();				

void Insertar(struct Agenda Contactos[]);			

/*Relevante e importante*/
void Buscar(struct Agenda Contactos[]);				
int BuscarMenuCategoria();							
void BuscarPorNombre(struct Agenda Contactos[]);	
void BuscarPorTelefono(struct Agenda Contactos[]);	
void BuscarPorCelular(struct Agenda Contactos[]);	
void BuscarPorEmail(struct Agenda Contactos[]);		


void Listar(struct Agenda Contactos[]);				
void Imprimir(struct Agenda Contactos[], int);		


void Actualizar(struct Agenda Contactos[], int);	

void Eliminar(struct Agenda Contactos[], int);		

int VerificarContacto(struct Agenda Contactos[], string);	


void CargarContactos(struct Agenda Contactos[]);
bool HayContactos(struct Agenda Contactos[]);		


void Detenerse();									
void LimpiarPantalla();								
void Dormir(int);									
int Salir();										




Agenda::Agenda() {
	Nombre 		= " ";								
	Telefono 	= "0";								
	Celular 	= "0";								
	Email 		= " ";								
	Fecha.Nacimiento = " ";							
}



int main(int argc, char *argv[]) {
	setlocale(LC_CTYPE, "spanish");
	int x;											
	int salir = 0;                                  
	Agenda Contactos[CANTIDAD]; 					
	CargarContactos(Contactos);						
	
	do{											
		if (HayContactos(Contactos)){				
			ContactosRegistrados = 0;
			ContactosEliminados  = 0;
			/*No hay contactos*/
			do {
				x = MenuPrimario();					
			} while(x < 1 || x > 2);
			
			switch (x){								
				case 1: 
					Insertar(Contactos);			
					break;
				case 2:
					salir = Salir();				
					break;
				default:
					cout << "Up's, ha ocurrido algo inesperado, presione una tecla para continuar!." << endl;
					system("PAUSE>NUL");
					break;
			}
			
		} else {
			
			do {
				x = MenuSecundario();				
			} while(x < 1 || x > 4);
			
			switch (x){								
				case 1: 
					Insertar(Contactos);
					break;
				case 2:
					Buscar(Contactos);				
					break;
				case 3: 
					Listar(Contactos);				
					break;
				case 4:
					salir = Salir();				
					break;
				default:
					cout << "Up's, ha ocurrido algo inesperado, presione una tecla para continuar!." << endl;
					system("PAUSE>NUL");
					break;
			}
		}
	}
	while (salir == 0);						
	
	return 0;
}

int MenuPrimario(){
	char x;										
	LimpiarPantalla();
	
	cout << Regla << endl;
	cout << "|\tBienvenido a tu Agenda Electr?nica (Contactos)\t    |" << endl;
	cout << Regla << endl;
	
	cout << "|\t\t\t\t\t\t\t    |" << endl;
	cout << "|\t\t       No hay contactos\t\t\t    |" << endl;
	cout << "|\t\t\t\t\t\t\t    |" << endl;
	
	cout << Regla << endl;
	cout << "| (1) Nuevo contacto           |        (2) Salir           |" << endl;
	cout << Regla << endl;
	
	cout << "Esperando respuesta: ";
	cin >> x;
	
	return x;									/*Convierte y retorna la opci?n seleccionada*/
}

int MenuSecundario(){
	int x;
	
	LimpiarPantalla();
	
	cout << Regla << endl;
	cout << "|\tBienvenido a tu Agenda Electr?nica (Contactos)\t    |" << endl;
	cout << Regla << endl;
	
	cout << "|\t\t\t\t\t\t\t    |" << endl;
	cout << "|\t\t      S? hay contactos" << " (" << (ContactosRegistrados - ContactosEliminados) << ")\t\t    |" << endl;
	cout << "|\t\t\t\t\t\t\t    |" << endl;
		
	cout << Regla << endl;
	cout << "| (1) Nuevo   | (2) Buscar   |  (3) Listar   |  (4) Salir   |" << endl;
	cout << Regla << endl;
	
	cout << "Esperando respuesta: ";
	cin >> x;
	return x;
}

void Insertar(struct Agenda Contactos[]){
	int x;
	int salir =0;						
	
	do{ 									
		
		
		if (ContactosRegistrados < CANTIDAD){
			cout << "\n\tN?mero de contacto: " << (ContactosRegistrados + 1) << endl;
			cout << "\tNombre:   ";
			cin >>  Contactos[ContactosRegistrados].Nombre;
			
			
			if (VerificarContacto(Contactos, Contactos[ContactosRegistrados].Nombre)){
				cout << "\n\tEl contacto \"" << Contactos[ContactosRegistrados].Nombre << "\" ya existe!" << endl;
				
				Contactos[ContactosRegistrados].Nombre = " ";
				
				
				do {
					cout << "\n\t?Desea agregar otro contacto?" << endl;
					cout << "\t(1) S?, (2) No: ";
					cin >> x;
					
				} while(x < 1 || x > 2);
				
				switch (x){
					case 1: 
						
						break;
					case 2:
						Detenerse();
						break;
					default:
						cout << "Up's, ha ocurrido algo inesperado, presione una tecla para continuar!." << endl;
						Detenerse();
						break;
				}
			}
			
			cout << "\tTel?fono: ";									
			cin >>  Contactos[ContactosRegistrados].Telefono;	
			
			cout << "\tCelular:  ";
			cin >>  Contactos[ContactosRegistrados].Celular;	
			
			cout << "\tEmail:    ";
			cin >>  Contactos[ContactosRegistrados].Email;	
			
			cout << "\tFecha de Nacimiento (DD/MM/AAAA): ";
			cin >>  Contactos[ContactosRegistrados].Fecha.Nacimiento;	
			
			ContactosRegistrados++;									
			
			cout << "\n\t?Agregado con ?xito!" << endl << endl;
			
		
			do {
				cout << "\n\t?Desea agregar otro contacto?" << endl;
				cout << "\t(1) S?, (2) No: ";
				cin >> x;
				
			} while(x < 1 || x > 2);
			
			switch (x){
				case 1: 
					
					break;
				case 2:
					Detenerse();
					break;
				default:
					cout << "Up's, ha ocurrido algo inesperado, presione una tecla para continuar!." << endl;
					Detenerse();
					break;
			}
			
		} else {
			cout << "Lleg? al l?mite de contactos permitidos en la agenda." << endl << endl;
		}
	}
	while(salir == 0);

	Detenerse();
	return;
}

void Buscar(struct Agenda Contactos[]){
	int x;
	int salir = 0;                                      
	
	do{ 
		LimpiarPantalla();
	
		do {
			x = BuscarMenuCategoria();				
		} while(x < 1 || x > 5);
		
		switch (x){
			case 1: 
				BuscarPorNombre(Contactos);			
				break;
			case 2:
				BuscarPorTelefono(Contactos);		
				break;
			case 3: 
				BuscarPorCelular(Contactos);		
				break;
			case 4: 
				BuscarPorEmail(Contactos);			
				break;
			case 5:
				salir = Salir();
				break;
			default:
				cout << "Error en el sistema,puse cualquier tecla para continuar :D" << endl;
				system("PAUSE>NUL");
				break;
		}
	
	}
	while(salir == 0);

	Detenerse();
	return;
}

int BuscarMenuCategoria(){
	int x; 
	
	cout << endl << "\n\t\t     Realizar busqueda por:" << endl << endl;
	cout << "(1)Nombre | (2)Telefono | (3)Celular | (4)Email | (5)Volver" << endl;
	cout << Regla << endl;
	
	cout << "Ingrese su opcion: ";
	cin >> x;
	
	
	return x;
}

void BuscarPorNombre(struct Agenda Contactos[]){
	int i = 0; 					
	int c = 0;					
	
	string PorNombre;
	
	cout << "\n\tIngrese el nombre: ";
	cin >>  PorNombre;
	cout << endl;
	
	
	for (i=0; i < ContactosRegistrados; i++){
		if ((Contactos[i].Nombre == PorNombre) ==0){				
			Imprimir(Contactos, i);							
			c++;
			break;
		}
	}
	
	if (c == 0)
		cout << "\n\tEl contacto \"" << PorNombre << "\" no se ha encontrado :(." << endl << endl;
	
	Detenerse();
	return;
}

void BuscarPorTelefono(struct Agenda Contactos[]){
	int i = 0; 
	int c = 0;
	
	string PorTelefono;
	
	cout << "\n\tIngrese el numero de telefono: ";
	cin >>  PorTelefono;
	cout << endl;
	
	for (i = 0; i < ContactosRegistrados; i++){
		if ((Contactos[i].Telefono == PorTelefono) ==0){
			Imprimir(Contactos, i);
			c++;
			break;
		}
	}
	
	if (c == 0){
		cout << "\n\tEl contacto \"" << PorTelefono << "\" no se ha encontrado. :(" << endl << endl;
	}
	
	Detenerse();
	return;
}

void BuscarPorCelular(struct Agenda Contactos[]){
	int i = 0; 
	int c = 0;					
	
	string PorCelular;
	
	cout << "\n\tDigite el numero de celular: ";
	cin >>  PorCelular;
	cout << endl;
	
	for (i = 0; i < ContactosRegistrados; i++){
		if ((Contactos[i].Celular == PorCelular) ==0){
			Imprimir(Contactos, i);
			c++;
			break;
		}
	}
	
	if (c == 0){
		cout << "\n\tEl contacto \"" << PorCelular << "\" no se ha encontrado. :(" << endl << endl;
	}
	
	Detenerse();
	return;
}

void BuscarPorEmail(struct Agenda Contactos[]){
	int i = 0; 
	int c = 0;					
	
	string PorEmail;
	
	cout << "\n\tIngrese el Email: ";
	cin >>  PorEmail;
	cout << endl;
	
	for (i = 0; i < ContactosRegistrados; i++){
		if ((Contactos[i].Email == PorEmail) ==0) {
			Imprimir(Contactos, i);
			c++;
			break;
		}
	}
	
	if (c == 0){
		cout << "\n\tEl contacto \"" << PorEmail << "\" no se ha encontrado. :(" << endl << endl;
	}
	
	Detenerse();
	return;
}


void Listar(struct Agenda Contactos[]){
	int i = 0;									
	int x = 0; 									
	int contactos_restantes = 0;				
	
	
	for (; i < ContactosRegistrados; i++){
		
		
		if (Contactos[i].Nombre != " "){
			if (i > 1){
				contactos_restantes = (ContactosRegistrados - x) - ContactosEliminados;
				Dormir(1);						
				
				if (contactos_restantes > 1)
					cout << "\t-- Aun quedan " << contactos_restantes << " por visualizar --" << endl;
				else if (contactos_restantes == 1)
					cout << "\t-- Solo queda " << contactos_restantes << " por visualizar --" << endl;
				
				Detenerse();
				cout << endl;
			}
			
			
			cout << "\n\tNumero de contacto: " << (x+1) << endl;
			cout << "\t\tNombre:   " << Contactos[i].Nombre << endl;
			cout << "\t\tTelefono: " << Contactos[i].Telefono << endl;
			cout << "\t\tCelular:  " << Contactos[i].Celular << endl;
			cout << "\t\tEmail:    " << Contactos[i].Email << endl;
			cout << "\t\tFecha N.: " << Contactos[i].Fecha.Nacimiento << endl << endl;
			
			x++;			
		}
	}
	
	cout << "\t Volver atras" << endl;
	Detenerse();
	return;
}
void Imprimir(struct Agenda Contactos[], int posicion){
	int x;
	
	
	cout << "\n\t\tNombre:   " << Contactos[posicion].Nombre << endl;
	cout << "\t\tTelefono: " << Contactos[posicion].Telefono << endl;
	cout << "\t\tCelular:  " << Contactos[posicion].Celular << endl;
	cout << "\t\tEmail:    " << Contactos[posicion].Email << endl;
	cout << "\t\tFecha N.: " << Contactos[posicion].Fecha.Nacimiento << endl << endl;
	
	
	do {
		cout << "\t  Opciones del contacto \"" << Contactos[posicion].Nombre << "\"" << endl;
		cout << "\t(1) Actualizar | (2) Eliminar | (3) Volver " << endl;
		cout << Regla << endl;
		
		cout << "Ingrese opcion: ";
		cin >> x;
		
		cout << endl;
		
	} while(x < 1 || x > 3);
	
	switch (x){
	case 1: 
		Actualizar(Contactos, posicion);				
		break;
	case 2:
		Eliminar(Contactos, posicion);					
		break;
	case 3: 
		if (Salir() == 1)
			return;
	default:
		cout << "\n\tError, pulse cualquier tecla para continuar" << endl;
		Detenerse();
		break;
	}
	
	return;
}

void Actualizar(struct Agenda Contactos[], int posicion){
	int x; 
	string Nombre, Telefono, Celular, Email;			
	int salir = 0;                                     
	
	do { 												
		
		Nombre 	= Contactos[posicion].Nombre;
		Telefono= Contactos[posicion].Telefono;
		Celular = Contactos[posicion].Celular;
		Email 	= Contactos[posicion].Email;
		
		
		do {
			cout << "\n\t¿Qué dato le gustaría actualizar de este contacto?" << endl;
			cout << "  (1)Nombre | (2)Teléfono | (3)Celular (4)Email | (5)Ninguno" << endl;
			cout << Regla << endl;
			
			cout << "Ingrese opcion: ";
			cin >> x;
			
			cout << endl;
			
		} while(x < 1 || x > 5);
		
		
		switch (x){
			case 1: 
				cout << "\tIngrese el nuevo nombre: ";
				cin >>  Contactos[posicion].Nombre;
				cout << "   Se ha actualizado de \"" << Nombre << "\" a " << "\"" << Contactos[posicion].Nombre << "\"" << endl; 
				break;
			case 2:
				cout << "\tDigite el nuevo telefono: ";
				cin >>  Contactos[posicion].Telefono;
				cout << "   Se ha actualizado de \"" << Telefono << "\" a " << "\"" << Contactos[posicion].Telefono << "\"" << endl; 
				break;
			case 3: 
				cout << "\tIngrese el nuevo celular: ";
				cin >>  Contactos[posicion].Celular;
				cout << "   Se ha actualizado de \"" << Celular << "\" a " << "\"" << Contactos[posicion].Celular << "\"" << endl; 
				break;
			case 4: 
				cout << "\tIngrese el nuevo email: ";
				cin >>  Contactos[posicion].Email;
				cout << "   Se ha actualizado de \"" << Email << "\" a " << "\"" << Contactos[posicion].Email << "\"" << endl; 
				break;
			case 5: 
				salir = Salir();
			default:
				cout << "\n\tError, pulse cualquier teclar para continuar." << endl;
				Detenerse();
				break;
		}
	}
	while(salir == 0);
	
	return;
}

void Eliminar(struct Agenda Contactos[], int posicion){
	string Nombre;
	
	Nombre = Contactos[posicion].Nombre;
	
	
	if (Salir() == 1){
		Contactos[posicion].Nombre 	= " ";
		Contactos[posicion].Telefono= "0";
		Contactos[posicion].Celular	= "0";
		Contactos[posicion].Email	= " ";
		ContactosEliminados++;
		
		cout << "\n?El ex-contacto \"" << Nombre <<  "\" ha sido eliminado con exito!\n\n";
	}
	
	return;
}

int VerificarContacto(struct Agenda Contactos[], string Nombre){
	int i = 0; 
	int c = 0;
	
	
	for (; i < ContactosRegistrados; i++){
		if (Contactos[i].Nombre == Nombre){
			c++;
			break;
		}
	}
	
	if (c == 0)
		return false;
	
	return true;
}

void CargarContactos(struct Agenda Contactos[]){
	int x;
	
	
	do {
		LimpiarPantalla();
			
		cout << Regla << endl;
		cout << "|\tBienvenido a la agendita Royoyo (Contactos)\t    |" << endl;
		cout << Regla << endl;
			
		cout << "(1) Cargar contactos previos | (2) Nueva agenda | (3) Salir |" << endl;
		cout << Regla << endl;
			
		cout << "Ingrese opcion: ";
		cin >> x;
		
			
	} while(x < 1 || x > 3);
		
	switch (x){
		case 1: 
			
			Contactos[ContactosRegistrados].Nombre 			= "Royoyo Faor";
			Contactos[ContactosRegistrados].Telefono 		= "959702100";
			Contactos[ContactosRegistrados].Celular 		= "959702100";
			Contactos[ContactosRegistrados].Email 			= "71960412@continental.edu.pe";
			Contactos[ContactosRegistrados].Fecha.Nacimiento= "19/12/1998";
			ContactosRegistrados++;
			
			
			Contactos[ContactosRegistrados].Nombre 			= "Jimy Moise";
			Contactos[ContactosRegistrados].Telefono 		= "123213123123";
			Contactos[ContactosRegistrados].Celular 		= "1231231233";
			Contactos[ContactosRegistrados].Email 			= "Jimyl@gmail.com";
			Contactos[ContactosRegistrados].Fecha.Nacimiento= "21/01/2000";
			ContactosRegistrados++;
			
			/*Tercer contacto*/
			Contactos[ContactosRegistrados].Nombre 			= "Andrezy";
			Contactos[ContactosRegistrados].Telefono 		= "12312323";
			Contactos[ContactosRegistrados].Celular 		= "12312312312";
			Contactos[ContactosRegistrados].Email 			= "andrezy@gmail.com";
			Contactos[ContactosRegistrados].Fecha.Nacimiento= "22/07/2002";
			ContactosRegistrados++;
			
			/*Cuarto contacto*/
			Contactos[ContactosRegistrados].Nombre 			= "Dianita";
			Contactos[ContactosRegistrados].Telefono 		= "12341232";
			Contactos[ContactosRegistrados].Celular 		= "131321312";
			Contactos[ContactosRegistrados].Email 			= "Dianitabonita@gmail.com";
			Contactos[ContactosRegistrados].Fecha.Nacimiento= "28/07/2003";
			ContactosRegistrados++;
			break;
		case 2:
			return;
		case 3: 
			if (Salir() == 1)
				return;
		default:
			cout << "\n\tError, pulse cualquier tecla para continuar." << endl;
			Detenerse();
			break;
	}
	
	return;
}

bool HayContactos(struct Agenda Contactos[]){
	int i = 0; 					
	int c = 0;					
	
	
	for (; i < CANTIDAD; i++)
		if (Contactos[i].Nombre != " ")
			c++;
	
	if (c > 0)
		return false; 
	
	return true;
}

void Detenerse(){
	cout << "\t¡Presione cualquier tecla para continuar!";
	system("PAUSE");								
}

void LimpiarPantalla(){
	system("CLS");									
}

void Dormir(int x){
	Sleep(x * 1000);							
}

int Salir(){
	int x;
	
	
	do {
		cout << "\n\t¿Estas seguro?" << endl;
		cout << "\t(1) Sí, (2) No: ";
		cin >> x;
		
	} while(x < 1 || x > 2);
	
	cout << endl;
	
	return x;
}
